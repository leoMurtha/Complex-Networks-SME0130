#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep  6 12:53:48 2019

@author: andre
"""

import osmnx as ox

G = ox.graph_from_place('New York, New York', network_type='drive')
G_projected = ox.project_graph(G)
ox.save_graphml(G_projected, filename='New_York.graphml')

G2 = ox.graph_from_place('Paris, France', network_type='drive')
G_projected2 = ox.project_graph(G2)
ox.save_graphml(G_projected2, filename='Paris.graphml')

G3 = ox.graph_from_place('São Paulo, Brazil', network_type='drive')
G_projected3 = ox.project_graph(G3)
ox.save_graphml(G_projected3, filename='Sao_Paulo.graphml')
